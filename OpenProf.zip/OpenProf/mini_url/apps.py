from django.apps import AppConfig


class MiniUrlConfig(AppConfig):
    name = 'mini_url'
